---
name: healthcheck
description: "对运行 OpenClaw 的主机进行安全审计，检查 SSH、防火墙、端口暴露、自动更新等，给出加固建议。"
metadata:
  {
    "openclaw":
      { "emoji": "🔒" },
  }
---

# 系统安全审计 Skill

对主机进行安全检查，找出潜在风险并给出加固方案。

## 适用场景

✅ **使用这个 skill 当用户说：**

- "帮我检查一下服务器安全吗？"
- "有哪些端口对外暴露了？"
- "SSH 配置安全吗？"
- "帮我做一次安全审计"
- "有什么需要修复的吗？"

## 工作流程

### 第一步：读取系统信息（只读）

自动检查以下内容：

- **操作系统**：`uname -a` / `sw_vers` / 系统版本
- **监听端口**：检查哪些端口在监听
- **防火墙状态**：是否开启
- **SSH 配置**：是否允许密码登录、root 登录
- **自动更新**：系统自动安全更新是否开启
- **磁盘加密**：FileVault / BitLocker / LUKS 是否启用
- **备份状态**：是否有定期备份

### 第二步：运行 OpenClaw 安全审计

```bash
# 快速审计
openclaw security audit

# 深度审计（更全面）
openclaw security audit --deep

# 自动修复安全默认值
openclaw security audit --fix
```

> 注意：`--fix` 只修复 OpenClaw 默认配置和文件权限，不会改动系统防火墙、SSH 或系统更新策略。

### 第三步：分析风险等级

根据使用场景选择风险配置文件：

| 配置文件 | 说明 |
|---------|------|
| **家庭/工作站在线** | 防火墙开启，远程访问限制在局域网或 tailnet |
| **VPS 加固** | 入口防火墙默认拒绝，最少开放端口，SSH 密钥登录，无 root 登录 |
| **开发者便利** | 允许更多本地服务，明确暴露警告 |
| **自定义** | 自定义约束（服务、暴露、更新频率） |

### 第四步：生成加固计划

给出包含以下内容的报告：

- 当前安全状况
- 与目标配置的差距
- 每一步的具体修复命令
- 访问恢复策略和回滚方案
- 风险和潜在锁机场景

## 常用命令

```bash
# 查看系统信息
uname -a

# 查看监听端口（Linux）
ss -ltnup

# 查看监听端口（macOS）
lsof -nP -iTCP -sTCP:LISTEN

# 查看防火墙状态（Linux）
ufw status

# 查看防火墙状态（macOS）
/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate

# 检查 SSH 配置
cat /etc/ssh/sshd_config | grep -E "PermitRootLogin|PasswordAuthentication|PubkeyAuthentication"

# 检查开放端口
nmap -sT localhost        # 需要 nmap
netstat -tlnp             # Linux
```

## 安全加固建议速查

### SSH 加固

```bash
# /etc/ssh/sshd_config 建议配置
PermitRootLogin no                # 禁止 root 登录
PasswordAuthentication no         # 禁止密码登录
PubkeyAuthentication yes          # 只允许密钥登录
MaxAuthTries 3                   # 最多尝试 3 次
```

### 防火墙规则（Linux）

```bash
# 只开放必要端口
ufw allow 22/tcp    # SSH
ufw allow 80/tcp   # HTTP
ufw allow 443/tcp  # HTTPS
ufw deny All       # 拒绝其他所有

# 启用防火墙
ufw enable
```

### 自动安全更新

```bash
# Ubuntu/Debian
apt install unattended-upgrades
dpkg-reconfigure unattended-upgrades

# CentOS/RHEL
yum install yum-cron
systemctl enable yum-cron
```

## 注意事项

- 所有**修改类**操作都需要用户明确确认才会执行
- 修改 SSH 配置前，确认当前连接不会断开
- 修改防火墙前，确认没有远程访问需求
- 建议在修改前备份原有配置文件
- 不确定时，优先给出**只读报告**，让用户自行决策

## 定时审计

建议定期运行安全审计：

```bash
# 添加每日安全检查 cron
openclaw cron add --name "healthcheck:daily" --every 86400000 --command "openclaw security audit"

# 检查更新状态
openclaw update status
```

---

## 适用人群

- 服务器管理员
- 有公网服务器的同学
- 想确保自己的 AI Agent 部署是安全的
- 求职时展示"我有安全意识"的证据
