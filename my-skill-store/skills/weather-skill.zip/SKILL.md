---
name: weather
description: "获取当前天气、气温、降雨预报，支持城市名和机场代码。"
homepage: https://wttr.in/:help
metadata:
  {
    "openclaw":
      {
        "emoji": "☔",
        "requires": { "bins": ["curl"] },
        "install":
          [
            {
              "id": "brew",
              "kind": "brew",
              "formula": "curl",
              "bins": ["curl"],
              "label": "安装 curl (brew)",
            },
          ],
      },
  }
---

# 天气查询 Skill

获取当前天气状况和天气预报。

## 触发场景

✅ **使用这个 skill 当用户问：**

- "天气怎么样？"
- "今天/明天会下雨吗？"
- "[城市] 温度多少？"
- "这周天气预报"
- 旅行规划天气查询

## 禁用场景

❌ **不要使用当：**

- 历史天气数据 → 使用天气档案/API
- 气候分析或趋势 → 使用专业数据源
- 局地微气候数据 → 使用本地传感器
- 恶劣天气警报 → 查询官方气象部门

## 使用方法

### 当前天气

```bash
# 单行摘要
curl "wttr.in/北京?format=3"

# 详细当前天气
curl "wttr.in/北京?0"
```

### 天气预报

```bash
# 3天预报
curl "wttr.in/北京"

# 一周预报
curl "wttr.in/北京?format=v2"

# 指定天数 (0=今天, 1=明天, 2=后天)
curl "wttr.in/北京?1"
```

### 格式化参数

```bash
# 单行格式
curl "wttr.in/北京?format=%l:+%c+%t+%w"

# JSON 输出
curl "wttr.in/北京?format=j1"

# PNG 图片
curl "wttr.in/北京.png"
```

### 格式化代码

- `%c` — 天气状况 emoji
- `%t` — 温度
- `%f` — "体感温度"
- `%w` — 风速
- `%h` — 湿度
- `%p` — 降水量
- `%l` — 地点

## 快速示例

**"北京天气怎么样？"**

```bash
curl -s "wttr.in/北京?format=%l:+%c+%t+(体感+%f),+%w+风,+%h+湿度"
```

**"今天会下雨吗？"**

```bash
curl -s "wttr.in/北京?format=%l:+%c+%p"
```

**"这周天气"**

```bash
curl "wttr.in/北京?format=v2"
```

## 备注

- 无需 API key（使用 wttr.in）
- 有频率限制，请勿频繁请求
- 支持全球大多数城市
- 支持机场代码：如 `curl wttr.in/PEK`
