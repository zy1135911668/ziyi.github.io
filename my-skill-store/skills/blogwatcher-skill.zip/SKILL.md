---
name: blogwatcher
description: "监控博客和 RSS/Atom 订阅源，发现更新时自动提醒。追踪你关注的技术博客、新闻站点。"
homepage: https://github.com/Hyaxia/blogwatcher
metadata:
  {
    "openclaw":
      {
        "emoji": "📰",
        "requires": { "bins": ["blogwatcher"] },
        "install":
          [
            {
              "id": "go",
              "kind": "go",
              "module": "github.com/Hyaxia/blogwatcher/cmd/blogwatcher@latest",
              "bins": ["blogwatcher"],
              "label": "安装 blogwatcher (go)",
            },
          ],
      },
  }
---

# 博客 / RSS 订阅监控 Skill

追踪你感兴趣的博客和 RSS/Atom 订阅源，发现更新时提醒。

## 适用场景

✅ **使用这个 skill 当用户说：**

- "帮我监控这几个博客，有更新通知我"
- "订阅某个网站的 RSS"
- "检查我关注的博客有没有新文章"
- "定时提醒我刷一下 xxx 博客"

## 安装

```bash
# 需要先安装 Go
# https://go.dev/dl/

# 安装 blogwatcher
go install github.com/Hyaxia/blogwatcher/cmd/blogwatcher@latest
```

验证安装：

```bash
blogwatcher --version
```

## 快速开始

### 添加订阅

```bash
# 添加一个博客
blogwatcher add "我的博客" https://example.com/feed

# 添加多个
blogwatcher add "GitHub Blog" https://github.com/blog/feed
blogwatcher add "Hacker News" https://hnrss.org/frontpage
```

### 查看订阅列表

```bash
blogwatcher blogs
```

输出示例：

```
追踪中的博客 (3):

  GitHub Blog
    URL: https://github.com/blog/feed
    上次检查: 2026-04-28 10:00

  Hacker News
    URL: https://hnrss.org/frontpage
    上次检查: 2026-04-28 10:00
```

### 检查更新

```bash
# 扫描所有订阅
blogwatcher scan
```

输出示例：

```
正在扫描 3 个博客...

  GitHub Blog
    来源: RSS | 发现: 2 | 新文章: 2

  Hacker News
    来源: RSS | 发现: 15 | 新文章: 5

发现 7 篇新文章！
```

### 查看文章列表

```bash
blogwatcher articles
```

### 标记已读

```bash
# 标记单篇已读
blogwatcher read 1

# 全部标记已读
blogwatcher read-all

# 删除某个博客
blogwatcher remove "GitHub Blog"
```

## 常用 RSS 订阅源

| 网站 | 订阅地址 |
|------|---------|
| GitHub Blog | `https://github.com/blog/feed` |
| Hacker News | `https://hnrss.org/frontpage` |
| 少数派 | `https://sspai.com/feed` |
| 科技媒体 | `https://www.techcrunch.com/feed/` |
| AI 新闻 | `https://venturebeat.com/category/ai/feed/` |

## 自动定时提醒

用 OpenClaw 定时任务自动检查：

```bash
# 每天早上 9 点检查一次
openclaw cron add --name "blogwatcher:daily" --every 86400000 --command "blogwatcher scan"
```

## 进阶用法

### 指定检查频率

```bash
# 每 30 分钟检查一次（用于追踪突发新闻）
blogwatcher add "紧急新闻" https://example.com/feed --interval 30m
```

### 输出 JSON 格式

```bash
blogwatcher articles --json
```

### 搜索文章

```bash
# 在已追踪的文章中搜索关键词
blogwatcher search "AI Agent"
```

## 注意事项

- 某些网站没有 RSS，需要找第三方工具（如 RSSHub）来生成
- 频繁检查可能对目标网站不友好，建议间隔设置在 30 分钟以上
- 大量订阅时定期清理已读文章，保持数据库轻盈
- 追踪垂直领域博客是很好的信息来源，比刷社交媒体效率高

## 适用人群

- 追踪技术博客，保持技术敏感度
- 监控竞品动态、新闻
- 构建个人知识收集系统
- 减少刷社交媒体的无效时间
