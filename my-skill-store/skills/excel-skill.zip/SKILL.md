---
name: excel
description: "上传 Excel/CSV 文件，自动进行数据分析、生成图表、输出关键指标报告。"
homepage: https://github.com/openclaw/skill-excel
metadata:
  {
    "openclaw":
      {
        "emoji": "📊",
        "requires": { "bins": ["python3"] },
        "install":
          [
            {
              "id": "brew",
              "kind": "brew",
              "formula": "python3",
              "bins": ["python3"],
              "label": "安装 Python 3 (brew)",
            },
          ],
      },
  }
---

# Excel 数据分析 Skill

上传 Excel 或 CSV 文件，自动完成数据处理、统计、图表生成。

## 触发场景

✅ **使用这个 skill 当用户说：**

- "分析这个 Excel 文件"
- "帮我看看这个表格的趋势"
- "生成数据报告"
- "计算这些数据的平均值"
- "把数据可视化出来"

## 前提条件

需要安装 Python 3 和以下库：

```bash
pip install pandas openpyxl matplotlib numpy
```

## 使用命令

### 基础数据分析

```python
import pandas as pd

# 读取 Excel 文件
df = pd.read_excel('data.xlsx')
# 或 CSV
df = pd.read_csv('data.csv')

# 查看基本信息
print(df.head())        # 前5行
print(df.info())        # 数据类型
print(df.describe())     # 统计摘要
print(df.columns)        # 列名
```

### 关键指标计算

```python
# 数值列的统计
print(df['销售额'].sum())    # 总和
print(df['销售额'].mean())   # 平均值
print(df['销售额'].median()) # 中位数
print(df['销售额'].std())    # 标准差
print(df['销售额'].min())    # 最小值
print(df['销售额'].max())    # 最大值

# 分组统计
grouped = df.groupby('部门')['销售额'].sum()
print(grouped)

# 计数
print(df['部门'].value_counts())
```

### 数据筛选

```python
# 按条件筛选
high_sales = df[df['销售额'] > 10000]
print(high_sales)

# 多条件筛选
result = df[(df['部门'] == '销售部') & (df['季度'] == 'Q1')]
print(result)
```

### 生成图表

```python
import matplotlib.pyplot as plt

# 设置中文字体（避免乱码）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 柱状图
df.groupby('月份')['销售额'].sum().plot(kind='bar')
plt.title('月度销售额')
plt.savefig('monthly_sales.png', dpi=150, bbox_inches='tight')
plt.close()

# 折线图
df.plot(x='日期', y='销售额')
plt.title('销售趋势')
plt.savefig('sales_trend.png', dpi=150, bbox_inches='tight')
plt.close()

# 饼图
df['占比'].plot(kind='pie', autopct='%1.1f%%')
plt.title('占比分布')
plt.savefig('distribution.png', dpi=150, bbox_inches='tight')
plt.close()
```

### 生成数据报告

```python
def generate_report(df, filename='report.txt'):
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("=" * 50 + "\n")
        f.write("数据分析报告\n")
        f.write("=" * 50 + "\n\n")

        f.write("【数据概览】\n")
        f.write(f"总行数: {len(df)}\n")
        f.write(f"总列数: {len(df.columns)}\n")
        f.write(f"列名: {', '.join(df.columns)}\n\n")

        f.write("【数值列统计】\n")
        f.write(str(df.describe()) + "\n\n")

        f.write("【缺失值】\n")
        f.write(str(df.isnull().sum()) + "\n")

    print(f"报告已生成: {filename}")

generate_report(df)
```

## 完整示例脚本

保存为 `analyze.py`：

```python
#!/usr/bin/env python3
import pandas as pd
import matplotlib.pyplot as plt
import sys

def analyze(file_path):
    # 根据扩展名判断格式
    if file_path.endswith('.xlsx'):
        df = pd.read_excel(file_path)
    elif file_path.endswith('.csv'):
        df = pd.read_csv(file_path)
    else:
        print("仅支持 .xlsx 和 .csv 文件")
        return

    print(f"✅ 成功读取文件，共 {len(df)} 行 × {len(df.columns)} 列")
    print(f"列名: {list(df.columns)}\n")
    print(df.describe())

    # 尝试自动绘图
    numeric_cols = df.select_dtypes(include='number').columns
    if len(numeric_cols) >= 1:
        col = numeric_cols[0]
        try:
            df[col].plot(kind='bar', title=f'{col} 分布')
            plt.savefig('output.png', dpi=150, bbox_inches='tight')
            plt.close()
            print(f"\n📊 图表已保存: output.png")
        except Exception as e:
            print(f"绘图失败: {e}")

if __name__ == '__main__':
    analyze(sys.argv[1])
```

使用：`python3 analyze.py your_data.xlsx`

## 常用场景

| 场景 | 方法 |
|------|------|
| 月度销售汇总 | `df.groupby('月份')['销售额'].sum()` |
| TOP 10 产品 | `df.nlargest(10, '销售额')` |
| 同比分析 | `df['今年'].compare(df['去年'])` |
| 数据去重 | `df.drop_duplicates()` |
| 空值填充 | `df.fillna(0)` |
| 导出结果 | `df.to_excel('result.xlsx')` 或 `df.to_csv('result.csv')` |

## 备注

- 处理大文件时注意内存占用
- 日期格式不统一时，用 `pd.to_datetime()` 转换
- 中文图表乱码：确保系统装了中文字体
- 敏感数据请勿上传到第三方服务器处理
