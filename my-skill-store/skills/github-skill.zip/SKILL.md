---
name: github
description: "使用 gh CLI 管理 GitHub issues、PR 状态、CI 日志、评论、评审和发布。"
homepage: https://cli.github.com
metadata:
  {
    "openclaw":
      {
        "emoji": "🐙",
        "requires": { "bins": ["gh"] },
        "install":
          [
            {
              "id": "brew",
              "kind": "brew",
              "formula": "gh",
              "bins": ["gh"],
              "label": "安装 GitHub CLI (brew)",
            },
            {
              "id": "apt",
              "kind": "apt",
              "package": "gh",
              "bins": ["gh"],
              "label": "安装 GitHub CLI (apt)",
            },
          ],
      },
  }
---

# GitHub 管理 Skill

使用 `gh` CLI 与 GitHub 仓库、issues、PR 和 CI 交互。

## 触发场景

✅ **使用这个 skill 当用户说：**

- "查一下这个 PR 的状态"
- "这个 issue 是谁开的？"
- "CI 为啥失败了？"
- "创建 / 合并一个 PR"
- "查看 GitHub 仓库的发布版本"

## 初始化配置

```bash
# 登录认证（一次性）
gh auth login

# 验证登录状态
gh auth status
```

## 禁用场景

❌ **不要使用当：**

- 本地 git 操作（commit、push、pull、branch）→ 直接用 `git`
- 非 GitHub 仓库（GitLab、Bitbucket）→ 用各自的 CLI
- 克隆仓库 → 直接用 `git clone`
- 复杂代码审查 → 使用 `coding-agent` skill
- 多文件 diff → 使用 `coding-agent` 或直接读文件

## Pull Requests

```bash
# 列出 PR
gh pr list --repo owner/repo

# 查看 PR 详情
gh pr view 55 --repo owner/repo

# 查看 CI 状态
gh pr checks 55 --repo owner/repo

# 创建 PR
gh pr create --title "feat: 新功能" --body "描述"

# 合并 PR（squash）
gh pr merge 55 --squash --repo owner/repo
```

## Issues

```bash
# 列出 open 的 issues
gh issue list --repo owner/repo --state open

# 创建 issue
gh issue create --title "Bug: 某某问题" --body "详细信息"

# 关闭 issue
gh issue close 42 --repo owner/repo
```

## CI / Workflow

```bash
# 查看最近运行
gh run list --repo owner/repo --limit 10

# 查看具体运行
gh run view <run-id> --repo owner/repo

# 只看失败的日志
gh run view <run-id> --repo owner/repo --log-failed

# 重新运行失败的任务
gh run rerun <run-id> --failed --repo owner/repo
```

## API 查询

```bash
# 获取 PR 指定字段
gh api repos/owner/repo/pulls/55 --jq '.title, .state, .user.login'

# 列出所有 labels
gh api repos/owner/repo/labels --jq '.[].name'

# 获取仓库统计
gh api repos/owner/repo --jq '{stars: .stargazers_count, forks: .forks_count}'
```

## JSON 输出

大多数命令支持 `--json` 获取结构化输出：

```bash
gh issue list --repo owner/repo --json number,title --jq '.[] | "\(.number): \(.title)"'

gh pr list --json number,title,state,mergeable --jq '.[] | select(.mergeable == "MERGEABLE")'
```

## 常用模板

**PR 审查摘要：**

```bash
PR=55 REPO=owner/repo
echo "## PR #$PR Summary"
gh pr view $PR --repo $REPO --json title,body,author,additions,deletions,changedFiles \
  --jq '"**\(.title)** by @\(.author.login)\n\n\(.body)\n\n📊 +\(.additions) -\(.deletions) across \(.changedFiles) files"'
gh pr checks $PR --repo $REPO
```

**Issue 分类浏览：**

```bash
gh issue list --repo owner/repo --state open --json number,title,labels,createdAt \
  --jq '.[] | "[\(.number)] \(.title) - \([.labels[].name] | join(", ")) (\(.createdAt[:10]))"'
```

## 备注

- 不在 git 目录时，记得加 `--repo owner/repo`
- 可以直接用 URL：`gh pr view https://github.com/owner/repo/pull/55`
- 有频率限制；重复查询用 `gh api --cache 1h`
- 支持 SSH 和 HTTPS 两种认证方式
