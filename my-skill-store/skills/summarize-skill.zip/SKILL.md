---
name: summarize
description: "对网页、YouTube视频、播客、文章、PDF和本地文件进行摘要或转录。"
homepage: https://summarize.sh
metadata:
  {
    "openclaw":
      {
        "emoji": "🧾",
        "requires": { "bins": ["summarize"] },
        "install":
          [
            {
              "id": "brew",
              "kind": "brew",
              "formula": "steipete/tap/summarize",
              "bins": ["summarize"],
              "label": "安装 summarize (brew)",
            },
          ],
      },
  }
---

# 摘要生成 Skill

快速总结网页、URL、YouTube 视频、本地文件。

## 触发场景

✅ **使用这个 skill 当用户说：**

- "总结一下这个链接"
- "这篇文章说了什么？"
- "这个视频讲了什么？"
- "what's this link/video about?"
- "transcribe this YouTube/video"

## 支持类型

| 类型 | 命令示例 |
|------|---------|
| 网页 | `summarize "https://example.com"` |
| YouTube | `summarize "https://youtu.be/xxx"` |
| 本地文件 | `summarize "/path/to/file.pdf"` |
| 播客 | `summarize "https://podcast.com/episode.mp3"` |

## 快速开始

```bash
# 网页摘要
summarize "https://example.com" --model google/gemini-3-flash-preview

# 文件摘要
summarize "/path/to/file.pdf" --model google/gemini-3-flash-preview

# YouTube 视频
summarize "https://youtu.be/dQw4w9WgXcQ" --youtube auto
```

## YouTube 模式

**字幕提取模式：**

```bash
# 提取字幕（不做摘要）
summarize "https://youtu.be/dQw4w9WgXcQ" --youtube auto --extract-only
```

如果用户要字幕但内容太长，先返回一个精简摘要，再问用户要展开哪部分。

## 输出长度

```bash
# 控制摘要长度
summarize "https://example.com" --length short   # 短
summarize "https://example.com" --length medium   # 中
summarize "https://example.com" --length long    # 长
summarize "https://example.com" --length xxl     # 超长
summarize "https://example.com" --length 500     # 指定字符数
```

## API Key 配置

支持多种 AI 模型供应商：

- **OpenAI**: `OPENAI_API_KEY`
- **Anthropic**: `ANTHROPIC_API_KEY`
- **xAI**: `XAI_API_KEY`
- **Google**: `GEMINI_API_KEY`

默认模型：`google/gemini-3-flash-preview`

## 其他参数

```bash
# JSON 格式输出（程序化处理）
summarize "https://example.com" --json

# 强制使用 Firecrawl 提取（绕过某些反爬）
summarize "https://example.com" --firecrawl auto

# YouTube 备选方案（需要 Apify）
summarize "https://youtu.be/xxx" --youtube auto  # 自动用 Apify fallback
```

## 配置文件

可选配置文件：`~/.summarize/config.json`

```json
{
  "model": "openai/gpt-4.2",
  "length": "medium"
}
```

## 环境变量

- `FIRECRAWL_API_KEY` — 用于被墙网站
- `APIFY_API_TOKEN` — YouTube fallback

## 备注

- 首次使用会自动下载模型
- 支持语言自动检测
- 对中文内容支持良好
- PDF 和本地文件需要文件可读
