---
name: email
description: "通过 SMTP 发送邮件，支持附件，可用于日报、通知、自动提醒。"
homepage: https://github.com/openclaw/skill-email
metadata:
  {
    "openclaw":
      {
        "emoji": "📧",
        "requires": { "env": ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS"] },
        "primaryEnv": "SMTP_PASS",
      },
  }
---

# 邮件发送 Skill

通过 SMTP 自动发送邮件，支持附件、多收件人、定时发送。

## 触发场景

✅ **使用这个 skill 当用户说：**

- "发一封邮件给 xxx"
- "发送日报"
- "把这个文件发过去"
- "定时提醒我"
- "发送失败通知"

## 配置

### 环境变量

```bash
# 必填
SMTP_HOST=smtp.gmail.com          # SMTP 服务器
SMTP_PORT=587                     # 端口（TLS 用 587，SSL 用 465）
SMTP_USER=your@email.com          # 邮箱地址
SMTP_PASS=your_app_password       # 授权码/密码

# 可选
SMTP_FROM="AI助手 <your@email.com>"  # 发件人显示名
SMTP_TLS=true                     # 是否使用 TLS（默认 true）
```

### Gmail 配置说明

1. 开启两步验证
2. 生成"应用专用密码"：Google Account → 安全性 → 应用密码
3. 把生成的 16 位密码填入 `SMTP_PASS`

### QQ 邮箱配置

```bash
SMTP_HOST=smtp.qq.com
SMTP_PORT=587
SMTP_USER=123456@qq.com
SMTP_PASS=your_authorization_code  # 在 QQ 邮箱设置 → 账户 中生成
```

## 使用命令

### 发送纯文本邮件

```bash
python3 -c "
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

msg = MIMEMultipart()
msg['From'] = os.environ['SMTP_FROM'] or os.environ['SMTP_USER']
msg['To'] = 'recipient@example.com'
msg['Subject'] = '邮件主题'

body = '这是邮件正文'
msg.attach(MIMEText(body, 'plain'))

with smtplib.SMTP(os.environ['SMTP_HOST'], int(os.environ['SMTP_PORT'])) as server:
    server.starttls()
    server.login(os.environ['SMTP_USER'], os.environ['SMTP_PASS'])
    server.send_message(msg)

print('发送成功')
"
```

### 发送 HTML 邮件

```python
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

msg = MIMEMultipart()
msg['From'] = os.environ['SMTP_FROM'] or os.environ['SMTP_USER']
msg['To'] = 'recipient@example.com'
msg['Subject'] = '日报 - 2026年4月28日'

html = """
<html><body>
<h2>今日工作汇总</h2>
<p>完成了 XXX 功能开发。</p>
<p>遇到的问题：无。</p>
</body></html>
"""
msg.attach(MIMEText(html, 'html'))

with smtplib.SMTP(os.environ['SMTP_HOST'], int(os.environ['SMTP_PORT'])) as server:
    server.starttls()
    server.login(os.environ['SMTP_USER'], os.environ['SMTP_PASS'])
    server.send_message(msg)
```

### 发送带附件的邮件

```python
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os

msg = MIMEMultipart()
msg['From'] = os.environ['SMTP_FROM'] or os.environ['SMTP_USER']
msg['To'] = 'recipient@example.com'
msg['Subject'] = '月度报告'

body = '请查收附件中的月度报告。'
msg.attach(MIMEText(body, 'plain'))

with open('report.pdf', 'rb') as f:
    part = MIMEBase('application', 'octet-stream')
    part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment', filename='report.pdf')
    msg.attach(part)

with smtplib.SMTP(os.environ['SMTP_HOST'], int(os.environ['SMTP_PORT'])) as server:
    server.starttls()
    server.login(os.environ['SMTP_USER'], os.environ['SMTP_PASS'])
    server.send_message(msg)
```

### 发送给多人

```python
msg['To'] = 'a@example.com, b@example.com'
# 或者
recipients = ['a@example.com', 'b@example.com']
server.send_message(msg, to_addrs=recipients)
```

## Python 脚本封装示例

将以下保存为 `send_mail.py`：

```python
#!/usr/bin/env python3
import smtplib, os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

def send_email(to, subject, body, html=None, attachments=None):
    msg = MIMEMultipart()
    msg['From'] = os.environ.get('SMTP_FROM') or os.environ['SMTP_USER']
    msg['To'] = to
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))
    if html:
        msg.attach(MIMEText(html, 'html'))

    if attachments:
        for filepath in attachments:
            with open(filepath, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment', filename=os.path.basename(filepath))
                msg.attach(part)

    with smtplib.SMTP(os.environ['SMTP_HOST'], int(os.environ['SMTP_PORT'])) as server:
        server.starttls()
        server.login(os.environ['SMTP_USER'], os.environ['SMTP_PASS'])
        server.send_message(msg)

if __name__ == '__main__':
    import sys
    send_email(
        to=sys.argv[1],
        subject=sys.argv[2],
        body=sys.argv[3]
    )
```

使用：`python3 send_mail.py "收件人" "主题" "正文"`

## 常见错误

| 错误 | 解决方法 |
|------|---------|
| `SMTPAuthenticationError` | 检查用户名/密码是否正确，确认开启了 SMTP |
| `SMTPConnectError` | 检查 SMTP_HOST 和端口是否正确 |
| Gmail 被拦截 | 确认使用了"应用专用密码"而非登录密码 |
| QQ 邮件发不出去 | 确认在 QQ 邮箱开启了 SMTP 服务 |

## 备注

- Gmail 要求 TLS/SSL，端口用 587 或 465
- 企业邮箱请咨询各自的 SMTP 配置
- 建议设置定时任务发送日报，减少重复工作
- 发送频率过高可能被 SMTP 服务器限流
