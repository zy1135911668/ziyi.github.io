---
name: taskflow
description: "编排多步骤的后台任务，管理复杂工作流，支持中断恢复、子任务关联、状态持久化。"
metadata:
  {
    "openclaw":
      { "emoji": "🪝" },
  }
---

# 任务流编排 Skill（TaskFlow）

当一个任务需要跨多个步骤、可能中断、涉及子任务协作时，用 TaskFlow 来管理。

## 适用场景

✅ **使用这个 skill 当：**

- 一个任务要分很多步，每步之间可能要等用户回复或外部系统
- 任务需要持久化状态，中途重启也能接着走
- 一个主任务要派生出多个子任务，统一管理
- 后台任务完成后要给用户一个清晰的汇总报告
- 需要等待网页抓取、API 返回等异步结果

## 核心概念

| 概念 | 说明 |
|------|------|
| **Flow** | 一次完整的工作流，有唯一 ID |
| **State** | 任务状态（运行中、等待中、已完成、失败） |
| **Child Task** | 子任务，挂在主 Flow 下 |
| **Wait** | 等待某个外部事件（用户回复、API 返回） |

## 工作流生命周期

```
createManaged()  → 创建 Flow
    ↓
runTask()       → 启动子任务
    ↓
setWaiting()    → 等待外部响应
    ↓
resume()        → 继续执行
    ↓
finish() / fail()  → 结束
```

## 使用示例

### 场景：自动处理用户反馈

```
用户提交反馈
    ↓
AI 分类（是 Bug / 功能建议 / 其他）
    ↓
如果是 Bug → 创建 GitHub Issue → 等待 Issue 链接回复给用户
如果是建议 → 加入待办列表 → 直接回复用户
    ↓
发送汇总邮件给负责人
    ↓
结束
```

### 代码示例

```javascript
// 创建任务流
const created = taskFlow.createManaged({
  controllerId: "feedback-bot",
  goal: "处理用户反馈",
  currentStep: "classify",
  stateJson: {
    feedback: "这个功能很好用",
    type: null,
    issueUrl: null,
  },
});

// 分类
const classify = taskFlow.runTask({
  flowId: created.flowId,
  runtime: "acp",
  childSessionKey: "agent:main:classifier",
  runId: "classify-1",
  task: "判断反馈类型：Bug / 功能建议 / 其他",
  status: "running",
});

// 等待子任务完成
const waiting = taskFlow.setWaiting({
  flowId: created.flowId,
  expectedRevision: created.revision,
  currentStep: "await_reply",
  stateJson: { type: "feature", ... },
  waitJson: {
    kind: "reply",
    channel: "slack",
    threadKey: "feedback:123",
  },
});

// 恢复并继续
const resumed = taskFlow.resume({
  flowId: waiting.flow.flowId,
  expectedRevision: waiting.flow.revision,
  status: "running",
  currentStep: "notify",
  stateJson: waiting.flow.stateJson,
});

// 完成任务
taskFlow.finish({
  flowId: resumed.flow.flowId,
  expectedRevision: resumed.flow.revision,
  stateJson: resumed.flow.stateJson,
});
```

## 适用场景举例

### 1. 面试流程自动化

```
收到简历
  ↓
AI 筛选（符合条件？）
  ↓ 是 → 发测评链接 → 等完成
  ↓ 否 → 发拒信
  ↓
收测评论卷 → AI 评分 → 给 HR 报告
```

### 2. 内容发布工作流

```
撰写文章
  ↓
发布到博客平台
  ↓
同步到社交媒体（多条）
  ↓
生成数据报告
  ↓
结束
```

### 3. 客服多轮对话

```
用户进线 → 理解问题 → 查知识库 → 回复
    ↓ 未解决
等待人工客服 → 客服回复 → 继续处理
    ↓
用户确认满意 → 关闭
```

## 与普通后台任务区别

| 对比 | 普通后台任务 | TaskFlow |
|------|------------|----------|
| 中断恢复 | 需要自己存状态 | 自动持久化 |
| 子任务管理 | 独立运行 | 有父子关系 |
| 等待外部事件 | 难实现 | 原生支持 |
| 状态查看 | 无统一视图 | 有完整视图 |

## 命令行操作

```bash
# 查看当前所有任务流
openclaw tasks list

# 查看某个任务流详情
openclaw tasks get <flowId>

# 手动触发恢复
openclaw tasks resume <flowId>

# 取消任务流
openclaw tasks cancel <flowId>
```

## 注意事项

- TaskFlow 更适合**复杂的、可能有中断的任务**
- 简单的一次性任务不需要用它
- 状态数据尽量只存最小必要信息
- 等待时间过长时，在 `blockedSummary` 里写清楚原因，方便排查

## 适用人群

- 需要自动化多步骤业务流程的同学
- 构建 AI Agent 产品（如客服机器人）
- 搭建复杂的企业工作流
- 分布式任务需要统一管理状态的场景
